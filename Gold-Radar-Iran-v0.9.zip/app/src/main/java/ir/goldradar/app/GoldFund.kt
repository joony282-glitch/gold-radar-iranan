package ir.goldradar.app

data class GoldFund(
    val symbol: String,
    var name: String = "",
    var insCode: String? = null,
    var price: Double? = null,
    var nav: Double? = null,
    var premium: Double? = null,
    var priceChange: Double? = null,
    var error: String? = null
)
