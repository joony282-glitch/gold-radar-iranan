package ir.goldradar.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

object TsetmcApi {
    private const val BASE = "https://cdn.tsetmc.com/api/"
    private const val UA = "Mozilla/5.0 (Android) GoldRadarIran/0.9"

    private fun get(path: String): JSONObject {
        val c = (URL(BASE + path).openConnection() as HttpURLConnection)
        c.requestMethod = "GET"
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "application/json")
        try {
            val text = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return JSONObject(text)
        } finally {
            c.disconnect()
        }
    }

    fun search(symbol: String): String? {
        val o = get("Instrument/GetInstrumentSearch/" + URLEncoder.encode(symbol, "UTF-8"))
        val a = o.optJSONArray("instrumentSearch") ?: return null
        var best: String? = null
        for (i in 0 until a.length()) {
            val x = a.optJSONObject(i) ?: continue
            val s = x.optString("lVal18AFC", "")
            if (s == symbol) return x.optString("insCode", null)
            if (best == null && s.isNotBlank()) best = x.optString("insCode", null)
        }
        return best
    }

    fun quote(insCode: String): Pair<Double?, Double?> {
        val o = get("ClosingPrice/GetClosingPriceInfo/$insCode")
        val x = o.optJSONObject("closingPriceInfo") ?: return Pair(null, null)
        val price = number(x, "pDrCotVal", "pClosing", "last")
        val change = number(x, "priceChange")
        return Pair(price, change)
    }

    fun nav(insCode: String): Double? {
        val o = get("Fund/GetETFByInsCode/$insCode")
        val x = o.optJSONObject("etf") ?: return null
        return number(x, "nav", "NAV", "navValue", "iNav", "iClose")
    }

    private fun number(o: JSONObject, vararg keys: String): Double? {
        for (k in keys) {
            if (!o.has(k) || o.isNull(k)) continue
            val v = o.opt(k)
            when (v) {
                is Number -> return v.toDouble()
                is String -> v.replace(",", "").toDoubleOrNull()?.let { return it }
            }
        }
        return null
    }

    fun loadFund(symbol: String): GoldFund {
        val f = GoldFund(symbol)
        try {
            val code = search(symbol)
            f.insCode = code
            if (code == null) {
                f.error = "نماد پیدا نشد"
                return f
            }
            val q = quote(code)
            f.price = q.first
            f.priceChange = q.second
            f.nav = nav(code)
            if (f.price != null && f.nav != null && f.nav!! > 0.0) {
                f.premium = (f.price!! - f.nav!!) / f.nav!! * 100.0
            } else {
                f.error = "NAV در دسترس نیست"
            }
        } catch (e: Exception) {
            f.error = e.message ?: "خطای شبکه"
        }
        return f
    }
}
