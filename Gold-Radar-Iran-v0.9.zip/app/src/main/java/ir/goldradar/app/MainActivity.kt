package ir.goldradar.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val executor = Executors.newFixedThreadPool(6)
    private val handler = Handler(Looper.getMainLooper())
    private var refreshing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        requestNotifications()
        setContentView(buildUi())
        scheduleWorker()
        refresh()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17,19,24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(24, 18, 24, 12)
        }

        val title = TextView(this).apply {
            text = "🟡 Gold Radar ایران"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 4)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val sub = TextView(this).apply {
            text = "رادار حباب صندوق‌های طلا | منبع بازار: TSETMC"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 12)
        }
        root.addView(sub)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val refresh = Button(this).apply { text = "↻ بروزرسانی"; setOnClickListener { refresh() } }
        val settings = Button(this).apply { text = "⚙ هشدار"; setOnClickListener { settings() } }
        buttons.addView(refresh, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(settings, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)

        status = TextView(this).apply {
            text = "در حال آماده‌سازی..."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        root.addView(status)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun refresh() {
        if (refreshing) return
        refreshing = true
        status.text = "در حال دریافت اطلاعات..."
        list.removeAllViews()
        val symbols = GoldRadarSymbols.ALL
        val results = mutableListOf<GoldFund>()
        var done = 0
        for (s in symbols) {
            executor.execute {
                val f = TsetmcApi.loadFund(s)
                synchronized(results) { results.add(f) }
                handler.post {
                    done++
                    status.text = "دریافت $done از ${symbols.size} | صندوق‌های معتبر بعد از تکمیل نمایش داده می‌شوند"
                    if (done == symbols.size) {
                        val good = results.filter { it.premium != null }.sortedByDescending { it.premium }
                        render(good, results.count { it.premium != null })
                        refreshing = false
                    }
                }
            }
        }
    }

    private fun render(items: List<GoldFund>, count: Int) {
        list.removeAllViews()
        val pos = GoldRadarPrefs.positive(this)
        val neg = GoldRadarPrefs.negative(this)
        status.text = "$count صندوق با قیمت و NAV معتبر | هشدار: ≥ ${"%.1f".format(pos)}٪ یا ≤ ${"%.1f".format(neg)}٪"

        for (f in items) {
            val p = f.premium ?: 0.0
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(18, 14, 18, 14)
                setBackgroundColor(Color.rgb(30,33,40))
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val top = TextView(this).apply {
                text = "${f.symbol}    حباب: ${"%+.2f".format(p)}٪"
                textSize = 18f
                setTextColor(if (p >= pos) Color.rgb(255,180,80) else if (p <= neg) Color.rgb(255,100,100) else Color.WHITE)
            }
            val detail = TextView(this).apply {
                text = "قیمت: ${f.price ?: "-"}   |   NAV: ${f.nav ?: "-"}   |   تغییر: ${f.priceChange ?: "-"}"
                textSize = 13f
                setTextColor(Color.LTGRAY)
                setPadding(0, 6, 0, 0)
            }
            card.addView(top)
            card.addView(detail)
            card.setOnClickListener {
                Toast.makeText(this, "${f.symbol}: حباب ${"%.2f".format(p)}٪", Toast.LENGTH_SHORT).show()
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 0, 0, 10)
            list.addView(card, lp)
        }
    }

    private fun settings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 10, 30, 0)
        }
        val pos = EditText(this).apply {
            hint = "حباب مثبت (مثلاً 2)"
            inputType = 8194
            setText(GoldRadarPrefs.positive(this@MainActivity).toString())
        }
        val neg = EditText(this).apply {
            hint = "حباب منفی (مثلاً -2)"
            inputType = 8194
            setText(GoldRadarPrefs.negative(this@MainActivity).toString())
        }
        box.addView(pos)
        box.addView(neg)
        AlertDialog.Builder(this)
            .setTitle("تنظیم هشدار حباب")
            .setView(box)
            .setMessage("وقتی حباب از این حدود عبور کند، اعلان ارسال می‌شود.")
            .setPositiveButton("ذخیره") { _, _ ->
                GoldRadarPrefs.set(this, pos.text.toString().toDoubleOrNull() ?: 2.0, neg.text.toString().toDoubleOrNull() ?: -2.0)
                Toast.makeText(this, "تنظیمات ذخیره شد", Toast.LENGTH_SHORT).show()
                refresh()
            }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun scheduleWorker() {
        val request = PeriodicWorkRequestBuilder<AlertWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "gold_radar_alerts", ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("gold_radar", "هشدار حباب طلا", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}
