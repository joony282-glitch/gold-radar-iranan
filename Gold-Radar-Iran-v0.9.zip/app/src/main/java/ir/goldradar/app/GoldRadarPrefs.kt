package ir.goldradar.app

import android.content.Context

object GoldRadarPrefs {
    private const val P = "gold_radar"
    private const val POS = "positive"
    private const val NEG = "negative"

    fun positive(c: Context) = c.getSharedPreferences(P, 0).getFloat(POS, 2f).toDouble()
    fun negative(c: Context) = c.getSharedPreferences(P, 0).getFloat(NEG, -2f).toDouble()

    fun set(c: Context, positive: Double, negative: Double) {
        c.getSharedPreferences(P, 0).edit()
            .putFloat(POS, positive.toFloat())
            .putFloat(NEG, negative.toFloat())
            .apply()
    }
}
