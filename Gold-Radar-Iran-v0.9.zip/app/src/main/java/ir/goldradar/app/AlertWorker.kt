package ir.goldradar.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AlertWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val symbols = GoldRadarSymbols.ALL
        var sent = 0
        for (symbol in symbols) {
            val f = TsetmcApi.loadFund(symbol)
            val p = f.premium ?: continue
            if (p >= GoldRadarPrefs.positive(applicationContext) || p <= GoldRadarPrefs.negative(applicationContext)) {
                notifyAlert(f, p)
                sent++
            }
        }
        if (sent > 0) Result.success() else Result.success()
    }

    private fun notifyAlert(f: GoldFund, p: Double) {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("gold_radar", "هشدار حباب طلا", NotificationManager.IMPORTANCE_HIGH))
        }
        val title = "هشدار حباب ${f.symbol}"
        val body = "حباب ${"%.2f".format(p)}٪ | قیمت ${f.price ?: "-"} | NAV ${f.nav ?: "-"}"
        val n = NotificationCompat.Builder(applicationContext, "gold_radar")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .build()
        nm.notify(f.symbol.hashCode(), n)
    }
}
